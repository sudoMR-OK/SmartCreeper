# Smart Creeper AI

A Fabric mod for **Minecraft 1.21.1** that overhauls Creeper behavior with stealth, navigation, and tower-building AI.

**Fabric Loader:** 0.16.4 · **Yarn Mappings:** 1.21.1+build.1

---

## Features

### 🕵️ Sneaky Creeper AI (Priority #1)
Targets players with realistic stealth mechanics:
- **Point-blank range (≤ 3 blocks):** Primes explosion immediately.
- **Outside point-blank range:** Calculates player gaze cone.
  - **If spotted:** Flees silently at **2.0× speed** to occluded cover.
  - **If unspotted:** Sneaks behind the player at **1.2× speed**.
- Yields to tower-building when path ends require vertical movement.

### 🚪 Door & Trapdoor Interaction (Priorities #2 & #3)
- **CreeperOpenDoorGoal** — Detects and opens closed wooden doors along the path.
- **CreeperInteractTrapdoorGoal** — Opens wooden trapdoors blocking navigation.

### 🗼 Creeper Towering (Priority #4)
When the target is **≥ 2 blocks above** and unreachable via standard paths:
- Navigates to the closest path-end.
- While climbing scaffolding, if the vertical path is blocked by a ceiling surrounded by air:
  1. Places horizontal TNT blocks underfoot as a bridge.
  2. Moves to an unobstructed spot.
  3. Resumes towering upward.

### 🔌 Mixin Enhancements
- **CreeperEntityMixin** — Injects goals in strict priority order, enables door navigation, expands follow range to **64 blocks**, and sets attack damage to **4.0**.
- **MobEntityMixin** — Loads **32 TNT** into naturally spawned Creepers via `MobEntity#initialize`.

### 📦 Inventory Support
- **CreeperInventoryProvider** — Public interface exposing Creeper inventory state.

---

## How to Compile

### Option 1: Gradle Wrapper (Easiest)
The project includes a pre-configured Gradle 8.9 wrapper.

```bash
chmod +x gradlew
./gradlew build
```

### Option 2: Local Gradle 8.9 (Recommended for Cloud Shell)
Install Gradle 8.9 persistently in your home directory:

```bash
wget https://services.gradle.org/distributions/gradle-8.9-bin.zip -P /tmp
mkdir -p ~/opt
unzip -d ~/opt /tmp/gradle-8.9-bin.zip
echo 'export PATH="$HOME/opt/gradle-8.9/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

Then build:

```bash
gradle build
```

---

## Installation

1. Build the mod JAR (see above).
2. The compiled JAR is at: `build/libs/smartcreeperai-0.1.0.jar`
3. Copy it to your `.minecraft/mods` folder.
4. Also install **Fabric API 0.116.9+1.21.1** in the same folder.

---

## Project Structure

```
src/main/java/com/main/smartcreeperai/
├── SmartCreeperMod.java               # Mod initializer
├── SneakyCreeperGoal.java             # Stealth AI (Priority #1)
├── CreeperOpenDoorGoal.java           # Door interaction (Priority #2)
├── CreeperInteractTrapdoorGoal.java   # Trapdoor interaction (Priority #3)
├── CreeperTowerGoal.java              # Tower-building AI (Priority #4)
├── CreeperInventoryProvider.java      # Inventory interface
└── mixin/
    ├── CreeperEntityMixin.java        # Creeper goal/stat injections
    └── MobEntityMixin.java            # TNT spawn injection
```
